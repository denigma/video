Websocket via different port
============================
WebSocket connection to 'ws://localhost:3000/index' failed: Unexpected response code: 200

https://groups.google.com/forum/?fromgroups=#!topic/meteor-talk/IwdBCz6S58U

http://stackoverflow.com/questions/5362100/can-websockets-or-ajax-long-polling-etc-run-on-a-different-port-than-the-ori

http://blog.silverbucket.net/post/31927044856/3-ways-to-configure-haproxy-for-websockets

https://getsatisfaction.com/esn/topics/websocket_in_chrome_fails_unexpected_response_code_200

https://github.com/ostinelli/misultin/issues/64